document.addEventListener('DOMContentLoaded', () => {
    const startButton = document.getElementById('startButton');
    const pauseButton = document.getElementById('pauseButton');
    const resetButton = document.getElementById('resetButton');
    const lapButton = document.getElementById('lapButton');
    const hoursDisplay = document.getElementById('hours');
    const minutesDisplay = document.getElementById('minutes');
    const secondsDisplay = document.getElementById('seconds');
    const millisecondsDisplay = document.getElementById('milliseconds');
    const lapsContainer = document.getElementById('laps');

    let startTime, updateTime, intervalId;
    let elapsedTime = 0;
    let isRunning = false;

    function startStopwatch() {
        if (!isRunning) {
            startTime = Date.now() - elapsedTime;
            intervalId = setInterval(updateStopwatch, 10);
            isRunning = true;
            toggleButtons(true);
        }
    }

    function pauseStopwatch() {
        if (isRunning) {
            clearInterval(intervalId);
            elapsedTime = Date.now() - startTime;
            isRunning = false;
            toggleButtons(false);
        }
    }

    function resetStopwatch() {
        clearInterval(intervalId);
        elapsedTime = 0;
        isRunning = false;
        updateDisplay(0, 0, 0, 0);
        lapsContainer.innerHTML = '';
        toggleButtons(false, true);
    }

    function updateStopwatch() {
        updateTime = Date.now() - startTime;
        let milliseconds = parseInt((updateTime % 1000) / 10);
        let seconds = parseInt((updateTime / 1000) % 60);
        let minutes = parseInt((updateTime / (1000 * 60)) % 60);
        let hours = parseInt((updateTime / (1000 * 60 * 60)) % 24);

        updateDisplay(hours, minutes, seconds, milliseconds);
    }

    function updateDisplay(hours, minutes, seconds, milliseconds) {
        hoursDisplay.innerHTML = pad(hours);
        minutesDisplay.innerHTML = pad(minutes);
        secondsDisplay.innerHTML = pad(seconds);
        millisecondsDisplay.innerHTML = pad(milliseconds, 2);
    }

    function pad(value, digits = 2) {
        return value.toString().padStart(digits, '0');
    }

    function recordLap() {
        if (isRunning) {
            const lapTime = `${hoursDisplay.innerHTML}:${minutesDisplay.innerHTML}:${secondsDisplay.innerHTML}.${millisecondsDisplay.innerHTML}`;
            const lapDiv = document.createElement('div');
            lapDiv.textContent = `Lap ${lapsContainer.children.length + 1}: ${lapTime}`;
            lapsContainer.appendChild(lapDiv);
        }
    }

    function toggleButtons(started, resetEnabled = false) {
        startButton.disabled = started;
        pauseButton.disabled = !started;
        resetButton.disabled = !started && !resetEnabled;
        lapButton.disabled = !started;
    }

    startButton.addEventListener('click', startStopwatch);
    pauseButton.addEventListener('click', pauseStopwatch);
    resetButton.addEventListener('click', resetStopwatch);
    lapButton.addEventListener('click', recordLap);
});
