document.addEventListener('DOMContentLoaded', () => {
    const apiKey = 'your_api_key_here'; // Replace with your actual API key
    const weatherUrl = 'https://api.openweathermap.org/data/2.5/weather';

    const locationInput = document.getElementById('locationInput');
    const getWeatherBtn = document.getElementById('getWeatherBtn');
    const useMyLocationBtn = document.getElementById('useMyLocationBtn');
    const locationName = document.getElementById('locationName');
    const temperature = document.getElementById('temperature');
    const conditions = document.getElementById('conditions');
    const humidity = document.getElementById('humidity');
    const windSpeed = document.getElementById('windSpeed');

    getWeatherBtn.addEventListener('click', () => {
        const location = locationInput.value;
        if (location) {
            fetchWeatherData(location);
        }
    });

    useMyLocationBtn.addEventListener('click', () => {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(position => {
                const { latitude, longitude } = position.coords;
                fetchWeatherDataByCoords(latitude, longitude);
            });
        } else {
            alert('Geolocation is not supported by your browser.');
        }
    });

    function fetchWeatherData(location) {
        const url = `${weatherUrl}?q=${location}&units=metric&appid=${apiKey}`;
        fetch(url)
            .then(response => response.json())
            .then(data => displayWeatherData(data))
            .catch(error => console.error('Error fetching weather data:', error));
    }

    function fetchWeatherDataByCoords(latitude, longitude) {
        const url = `${weatherUrl}?lat=${latitude}&lon=${longitude}&units=metric&appid=${apiKey}`;
        fetch(url)
            .then(response => response.json())
            .then(data => displayWeatherData(data))
            .catch(error => console.error('Error fetching weather data:', error));
    }

    function displayWeatherData(data) {
        if (data.cod === 200) {
            locationName.textContent = `Location: ${data.name}, ${data.sys.country}`;
            temperature.textContent = `Temperature: ${data.main.temp}°C`;
            conditions.textContent = `Conditions: ${data.weather[0].description}`;
            humidity.textContent = `Humidity: ${data.main.humidity}%`;
            windSpeed.textContent = `Wind Speed: ${data.wind.speed} m/s`;
        } else {
            alert('Error: ' + data.message);
        }
    }
});
