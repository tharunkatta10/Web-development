document.addEventListener('DOMContentLoaded', () => {
    // Example of smooth scrolling for navigation links
    const links = document.querySelectorAll('nav ul li a');
    
    for (const link of links) {
        link.addEventListener('click', smoothScroll);
    }

    function smoothScroll(event) {
        event.preventDefault();
        const targetId = event.target.get
